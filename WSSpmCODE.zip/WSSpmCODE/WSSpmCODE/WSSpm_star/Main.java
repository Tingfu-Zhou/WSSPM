package ca.pfv.spmf.algorithms.frequentpatterns.apriori_HT;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.List;
import java.util.Collections;
import java.util.ArrayList;
import ca.pfv.spmf.tools.MemoryLogger;

public class Main {
    //WSSPM*
    public static String filePathDB;
    public static String filePathW;
    public static String filePathS;
    public static HashMap<Integer,String> idDB;
    public static HashMap<String,Float> itemweight;

    public static float threshold;//the target FWER
    public static int num;
    public static int minfreq;
    public static BigDecimal siglevel;
    public static int totaln;
    public static int n1;

    public static BigDecimal deltastar;

    public static ArrayList<BigDecimal> pjmin;
    public static HashMap<BigDecimal, ArrayList<String>> record;
    public static int numpattern;

    public static void main(String[] arg) throws IOException {
        MemoryLogger.getInstance().reset();
        //filePathDB = "C:\\Users\\86138\\Desktop\\DPB10201.txt";
        //filePathDB = "C:\\Users\\86138\\Desktop\\0705172A.txt";
        filePathDB = "C:\\Users\\86138\\Desktop\\uniflna.txt";
        filePathW = "C:\\Users\\86138\\Desktop\\itemweight.txt";
        filePathW = "C:\\Users\\86138\\Desktop\\itemweighte.txt";
        filePathS = "C:\\Users\\86138\\Desktop\\pattern.txt";

        idDB = readfileDB(filePathDB);
        itemweight = readfileW(filePathW);

        //these three function stated above, need to be modified with the change of data type/outline
        n1=50;//n1<totaln; here, I choose the size of n1
        threshold = 0.01f;
        num=1000;

        //following part is the line 3 in main function
        totaln= idDB.size();
        //here, in Fisher's exact test n1, n, and x_p is fixed

        /* start */
        long startTime = System.nanoTime();
        //line 1
        HashMap<Integer, Float> LMW = calLMW();
        Float tsmw = caltsmw(LMW);
        Float MW = calMW(LMW);
        ProcessNext.MW = MW;
        //share global variables
        ProcessNext.LMW = LMW;
        ProcessNext.tsmw = tsmw;
        ProcessNext.itemweight = itemweight;
        ProcessNext.DB = idDB;
        ProcessNext.n1 = n1;
        ProcessNext.totaln = totaln;
        ProcessNext.num = num;
        ProcessNext.threshold = threshold;
        MemoryLogger.getInstance().checkMemory();

        List<ArrayList<Integer>> Cj = new ArrayList<ArrayList<Integer>>();//line 2 to line 5
        pjmin = new ArrayList<BigDecimal>();
        for(int j=0; j<num;j++){// in Cj the index start from 0
            List<Integer> temp = new ArrayList<Integer>();
            for(int i = 0; i<totaln;i++){
                temp.add(i);// here is seqID
            }
            Collections.shuffle(temp);
            Cj.add((ArrayList<Integer>) temp);
            /* the 1-th to n1-th in the list is labeled as c1 the rest (n1+1) to
             * n-th is labeled as c0*/
            pjmin.add(BigDecimal.valueOf(1.0f));
        }
        MemoryLogger.getInstance().checkMemory();
        ProcessNext.Cj = Cj;
        ProcessNext.pjmin = pjmin;
        minfreq=1;
        siglevel=lowerp(minfreq);
        ProcessNext.siglevel = siglevel;
        ProcessNext.minfreq = minfreq;
        ProcessNext.main();
        MemoryLogger.getInstance().checkMemory();
        /*calculate the finial delta;now we calculate the α-quantile of the set minimum p-value*/
        Collections.sort(pjmin);
        float temp = threshold*num;
        if(temp>1000){
            deltastar = pjmin.get(1000);
        }else{
            deltastar = pjmin.get((int) temp-1);
        }

        //following part is used for case study
        //here, hashmap "record" to record the pmin and its related pattern.
        //first sort it in ascending order
        ArrayList<BigDecimal> sorted = new ArrayList<>(record.keySet());
        Collections.sort(sorted);
        ArrayList<String> objpattern = new ArrayList<String>();
        for(int i = 0; i < sorted.size(); i++){
            BigDecimal thep = sorted.get(i);
            if(thep.compareTo(deltastar)!=1){
                ArrayList<String> patters = record.get(thep);
                for (int n = 0; n < patters.size(); n++) {
                    String thepattern = patters.get(n);
                    objpattern.add(thepattern);
                }
            }else{
                break;
            }
        }
        MemoryLogger.getInstance().checkMemory();
        /* end */
        long endTime   = System.nanoTime();
        long totalTime = endTime - startTime;
        writefile(filePathS, objpattern);
        System.out.println(totalTime);
        System.out.println(" Max Memory ~ " + MemoryLogger.getInstance().getMaxMemory() + " MB");
        System.out.println("Final minimum support ~ " + minfreq);
        System.out.println("number of tested patterns ~ " + numpattern);
    }



    public static BigDecimal lowerp(Integer theminfreq){
        BigDecimal thesiglevel = BigDecimal.valueOf(-1.0f);//initialize
        if(theminfreq>n1 && theminfreq<=totaln){//the case of 0<=x_p<=n1
            thesiglevel = BigDecimal.valueOf(1).divide(combination(totaln,n1), 30,BigDecimal.ROUND_HALF_UP);
            return thesiglevel;
        } else if (theminfreq>=0 && theminfreq<=n1) {//the case of n1<x_p<=n
            int apmin = 0;
            int apmax = n1;
            if((theminfreq-totaln+n1)>0){
                apmin=(theminfreq-totaln+n1);
            }
            if(theminfreq<n1){
                apmax=theminfreq;
            }
            //here the
            BigDecimal tempmax = calpvalue(apmax,apmin, apmax,theminfreq);
            BigDecimal tempmin = calpvalue(apmin,apmin, apmax,theminfreq);
            MemoryLogger.getInstance().checkMemory();
            if(tempmin.compareTo(tempmax)==1){
                thesiglevel=tempmax;
            }else{
                thesiglevel=tempmin;
            }
            return thesiglevel;
        }
        MemoryLogger.getInstance().checkMemory();
        return thesiglevel;
    }






    private static BigDecimal calpvalue(int u, int asmin, int asmax,int xp){
        BigDecimal psu = BigDecimal.valueOf(0.0f);
        BigDecimal Pu = combination(n1, u).multiply(combination((totaln - n1), (xp - u))).divide(combination(totaln, u), 30,BigDecimal.ROUND_HALF_UP);
        for (int k = asmin; k <= asmax; k++) {
            BigDecimal temp = combination(n1, k).multiply(combination((totaln - n1), (xp - k))).divide(combination(totaln, k), 30,BigDecimal.ROUND_HALF_UP);
            if(temp.compareTo(Pu)!=1){
                psu=psu.add(temp);
            }
        }
        MemoryLogger.getInstance().checkMemory();
        return psu;
    }



    private static BigDecimal factorial(int n) {
        BigDecimal sum = BigDecimal.valueOf(1.0f);
        while (n > 0) {
            BigDecimal temp = BigDecimal.valueOf(n);
            sum = sum.multiply(temp);
            n--;
        }
        MemoryLogger.getInstance().checkMemory();
        return sum;
    }

    private static BigDecimal combination(int n, int m) {
        MemoryLogger.getInstance().checkMemory();
        return factorial(n).divide (factorial(n - m).multiply(factorial(m)),20,BigDecimal.ROUND_HALF_UP);
    }





    /*public static HashMap<Integer, String> readfileDB(String filepath) {
        HashMap<Integer, String> theidDB = new HashMap<Integer, String>();
        try {
            FileInputStream fin = new FileInputStream(filepath);
            InputStreamReader reader = new InputStreamReader(fin);
            BufferedReader in = new BufferedReader(reader);
            String str = "";
            String temp = "";
            int i = 0;
            while ((temp = in.readLine()) != null) {//now each paragraph is a sequence
                if(temp.charAt(0)!='>') {
                    theidDB.put(i, temp);
                    i++;
                }
            }
            in.close();
        } catch (IOException e) {
            e.getStackTrace();
        }
        return theidDB;
    }*/


    /*public static HashMap<Integer, String> readfileDB(String filepath) {//DRB_10101
        HashMap<Integer, String> theidDB = new HashMap<Integer, String>();
        try {
            FileInputStream fin = new FileInputStream(filepath);
            InputStreamReader reader = new InputStreamReader(fin);
            BufferedReader in = new BufferedReader(reader);
            String temp = "";
            int i = 0;
            String[] tempArray;
            while ((temp = in.readLine()) != null) {//now each paragraph is a sequence
                tempArray = temp.split("\t");
                String seq = tempArray[0];
                theidDB.put(i,seq);
                i++;
                if(i>=100){
                    break;
                }
            }
            in.close();
        } catch (IOException e) {
            e.getStackTrace();
        }
        return theidDB;
    }*/


    public static HashMap<Integer, String> readfileDB(String filepath) {//uniflna
        HashMap<Integer, String> theidDB = new HashMap<Integer, String>();
        try {
            FileInputStream fin = new FileInputStream(filepath);
            InputStreamReader reader = new InputStreamReader(fin);
            BufferedReader in = new BufferedReader(reader);
            String temp = "";
            int i = 0;
            while ((temp = in.readLine()) != null) {//now each paragraph is a sequence
                theidDB.put(i, temp);
                i++;
                if(i==100){
                    break;
                }
            }
            in.close();
        } catch (IOException e) {
            e.getStackTrace();
        }
        return theidDB;
    }



    /*public static HashMap<Integer, String> readfileDB(String filepath) {//f> 0705172A
        HashMap<Integer, String> theidDB = new HashMap<Integer, String>();
        try {
            FileInputStream fin = new FileInputStream(filepath);
            InputStreamReader reader = new InputStreamReader(fin);
            BufferedReader in = new BufferedReader(reader);
            String str = "";
            String temp = "";
            int i = 0;
            while ((temp = in.readLine()) != null) {//now each paragraph is a sequence
                if(temp.charAt(0)!='>') {
                    str = str + temp;
                }else if(str.length()!=0){
                    theidDB.put(i, str);
                    str = "";
                    i++;
                }
            }
            in.close();
        } catch (IOException e) {
            e.getStackTrace();
        }
        return theidDB;
    }*/




    public static Float calMW(HashMap<Integer,Float> seqLMW) {//for the usage of weighted upper-bound
        Float MW = 0f;
        for(Integer id: seqLMW.keySet()) {
            if(seqLMW.get(id)>MW){
                MW = seqLMW.get(id);
            }
        }
        MemoryLogger.getInstance().checkMemory();
        return MW;
    }


    public static HashMap<String,Float> readfileW(String filepath) {
        //copy one
        //This function need to be changed as the change of original DB
        HashMap<String, Float> theitemweight = new HashMap<String, Float>();
        try {
            FileInputStream fin = new FileInputStream(filepath);
            InputStreamReader reader = new InputStreamReader(fin);
            BufferedReader in = new BufferedReader(reader);
            //here, i use hashmap to store the weight of item
            String str = "";
            String[] tempArray;
            while ((str = in.readLine())!= null) {//Here, by default, I store the weight of each item in each row,
                tempArray = str.split(" ");//Weights and items are separated by Spaces
                theitemweight.put(tempArray[0],Float.parseFloat(tempArray[1]));
                //tempArray[0] is the item, tempArray[1] is the weight value of the item
            }
            in.close();
        } catch(IOException e) {
            e.getStackTrace();
        }
        return theitemweight;
    }

    public static void writefile(String filePath, ArrayList<String> patterns){
        //copy one
        try{
            File file = new File(filePath);
            FileOutputStream fos = null;
            if(!file.exists()){
                file.createNewFile();
                fos = new FileOutputStream(file);
            }else{
                fos = new FileOutputStream(file,true);
            }
            OutputStreamWriter osw = new OutputStreamWriter(fos, "UTF-8");
            for(int i = 0; i<patterns.size();i++){
                String pattern = patterns.get(i);
                osw.write(pattern);
                osw.write("\r\n");
            }
            osw.close();
        }catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static HashMap<Integer,Float> calLMW(){//calculate the LMW of each seq in DB
        //copy one
        HashMap<Integer, Float> seqLMW = new HashMap<Integer, Float>();
        //debug 1
        //System.out.print(idDB.size());
        for(Integer i: idDB.keySet()){
            String str = idDB.get(i);
            float thissmw = 0f;
            for(int j = 0; j<str.length();j++) {
                String s = String.valueOf(str.charAt(j));
                if(itemweight.get(s)>thissmw) {
                    thissmw = itemweight.get(s);
                }
            }
            seqLMW.put(i,thissmw);
        }
        MemoryLogger.getInstance().checkMemory();
        return seqLMW;
    }

    public static Float caltsmw(HashMap<Integer,Float> seqLMW) {
        //copy one
        Float tsmw = 0f;
        for(Integer i: seqLMW.keySet()) {
            tsmw = tsmw + seqLMW.get(i);
        }
        MemoryLogger.getInstance().checkMemory();
        return tsmw;
    }


}